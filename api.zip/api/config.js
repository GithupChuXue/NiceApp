// 这是一个全局的配置文件

module.exports = {
    // 加密和解密的用户秘钥
    jwtSecretKey: 'team-six',
    expiresIn: '10h',
}